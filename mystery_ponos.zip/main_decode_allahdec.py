#Декоднул @allahdec.
__import__("webbrowser").open("https://t.me/+-aF7ZoooDo5mYmVi")


import os  #Декоднул @allahdec.
import fake_useragent  #Декоднул @allahdec.
import webbrowser  #Декоднул @allahdec.
import requests  #Декоднул @allahdec.
import termcolor  #Декоднул @allahdec.
import pyfiglet  #Декоднул @allahdec.
from fake_useragent import UserAgent  #Декоднул @allahdec.
from termcolor import colored  #Декоднул @allahdec.
import subprocess  #Декоднул @allahdec.
import sys  #Декоднул @allahdec.
import time  #Декоднул @allahdec.
import platform  #Декоднул @allahdec.
import random  #Декоднул @allahdec.
import platform  #Декоднул @allahdec.

def get_device_type():  #Декоднул @allahdec.
    system = platform.system()
    machine = platform.machine()
    if system == 'Linux':  #Декоднул @allahdec.
        if 'arm' in machine or 'aarch64' in machine:  #Декоднул @allahdec.
            return 'Mobile'  #Декоднул @allahdec.
        else:  #Декоднул @allahdec.
            return 'Unknown'  #Декоднул @allahdec.
    elif system == 'Darwin':  #Декоднул @allahdec.
        return 'PC'  #Декоднул @allahdec.
    elif system == 'Windows':  #Декоднул @allahdec.
        return 'PC'  #Декоднул @allahdec.
    else:  #Декоднул @allahdec.
        return 'Unknown'  #Декоднул @allahdec.

device_type = get_device_type()

def gradient_text(text):  #Декоднул @allahdec.
    colored_text = text
    return colored_text  #Декоднул @allahdec.

url = 'https://t.me/decoded_softs'
webbrowser.open(url)
os.system('cls' if os.name == 'nt' else 'clear')

banner = '''
                 ███▄ ▄███▓▓██   ██▓  ██████ ▄▄▄█████▓▓█████  ██▀███ ▓██   ██▓
                ▓██▒▀█▀ ██▒ ▒██  ██▒▒██    ▒ ▓  ██▒ ▓▒▓█   ▀ ▓██ ▒ ██▒▒██  ██▒
                ▓██    ▓██░  ▒██ ██░░ ▓██▄   ▒ ▓██░ ▒░▒███   ▓██ ░▄█ ▒ ▒██ ██░
                ▒██    ▒██   ░ ▐██▓░  ▒   ██▒░ ▓██▓ ░ ▒▓█  ▄ ▒██▀▀█▄   ░ ▐██▓░
                ▒██▒   ░██▒  ░ ██▒▓░▒██████▒▒  ▒██▒ ░ ░▒████▒░██▓ ▒██▒ ░ ██▒▓░
                ░ ▒░   ░  ░   ██▒▒▒ ▒ ▒▓▒ ▒ ░  ▒ ░░   ░░ ▒░ ░░ ▒▓ ░▒▓░  ██▒▒▒ 
                ░  ░      ░ ▓██ ░▒░ ░ ░▒  ░ ░    ░     ░ ░  ░  ░▒ ░ ▒░▓██ ░▒░ 
                ░      ░    ▒ ▒ ░░  ░  ░  ░    ░         ░     ░░   ░ ▒ ▒ ░░  
                       ░    ░ ░           ░              ░  ░   ░     ░ ░     
                            ░ ░                                       ░ ░     
    [!] by @allahdec                                                     [!] Продажа можно 
    [!] Owner: allahdec                                                [!] Price: Free
    [!] BiO: @allahbioo                                          [!] Version: 2.4
    [!] Базы: [300+ Источников]; [4kkk+ Объектов]; [30kkk+ Записей]
    [!] При использовании Mystery включайте VPN
 ╔════════════════════════════════════════════════════════════════════════════════════════════╗   
 ║ 1.  Поиск по телефону                                    28. Поиск Уязвимостей Сайта       ║  
 ║ 2.  Поиск базы данных сайта                              29. Мануал [Бан ВК]               ║ 
 ║ 3.  Поиск по IP                                          30. Информация о E-Mail           ║
 ║ 4.  Поиск по OSINT                                       31. Мой HWID                      ║ 
 ║ 5.  Поиск по базам данных                                32. Фишинг [ГБ]                   ║ 
 ║ 6.  Поиск по LeakOsint                                   33. Code Decoder [+]              ║ 
 ║ 7.  Поиск по NickName                                    34. Генератор Key LeakOsint       ║ 
 ║ 8.  Поиск по Утечкам                                     35. Chat GPT                      ║ 
 ║ 9.  Поиск по VK                                          36. Временная почта               ║
 ║ 10. Поиск по Shodan                                      37. Поиск судебных дел            ║
 ║ 11. Поиск по Банковской Карте                            38. Разбан аккаунта Telegram      ║
 ║ 12. Мой IP                                               39. Сокращение ссылок             ║
 ║ 13. IP сайта                                             40. Поиск по Ф.И.О                ║
 ║ 14. Проверка нагрузки на сайт                            41. Поиск по Google Frame Works   ║
 ║ 15. Сканер портов сайта                                  42. Снос TikTok                   ║
 ║ 16. Бесплатные Proxy                                     43. Поиск по GeOsint              ║
 ║ 17. Создать почту Gmail                                  44. Анонимное Письмо              ║
 ║ 18. Bomber Telegram                                      45. Поиск по соц. сетям           ║
 ║ 19. Bomber Number                                        46. Поиск по Gravatar             ║
 ║ 20. Сносер Telegram                                      47. Поиск по Roblox               ║
 ║ 21. Парсинг Групп Telegram                               48. Поиск по DoxBin               ║
 ║ 22. Отправить Донос РФ                                   49. Поиск по Email [Beta]         ║
 ║ 23. DdoS                                                 50. Поиск по члену                ║
 ║ 24. Возраст Telegram Account                                                               ║
 ║ 25. Текст для Сватинга                                                                     ║
 ║ 26. Парсинг Сайта                                                                          ║
 ║ 27. Зашифровать код                                       [CTRL + Z] - Выход               ║
 ╚════════════════════════════════════════════════════════════════════════════════════════════╝'''

print(colored(banner, 'magenta'))
print(colored(f'                                      Устройсво: {device_type}', 'magenta'))
print(' ')

def main():  #Декоднул @allahdec.
    while True:  #Декоднул @allahdec.
        try:  #Декоднул @allahdec.
            choice = input('Выберите опцию: ')
            scripts = {
                '1': 'searchphone.py',
                '2': 'checkbd.py',
                '3': 'searchip.py',
                '4': 'osint.py',
                '5': 'searchbd.py',
                '6': 'LeakOsint.py',
                '7': 'searchnick.py',
                '8': 'searchleaks.py',
                '9': 'searchvk.py',
                '10': 'searchshodan.py',
                '11': 'searchcard.py',
                '12': 'myip.py',
                '13': 'ipweb.py',
                '14': 'loadsite.py',
                '15': 'portcheck.py',
                '16': 'freeproxy.py',
                '17': 'gmail.py',
                '18': 'fludcode.py',
                '19': 'bomber.py',
                '20': 'snos.py',
                '21': 'parsergroup.py',
                '22': 'donos.py',
                '23': 'ddos.py',
                '24': 'createtgaccount.py',
                '25': 'swat.py',
                '26': 'webparsing.py',
                '27': 'obfuscate.py',
                '28': 'webchecker.py',
                '29': 'banvk.py',
                '30': 'infoemail.py',
                '31': 'hwid.py',
                '32': 'fishing.py',
                '33': 'decoder.py',
                '34': 'genkey.py',
                '35': 'chat_gpt.py',
                '36': 'tempemail.py',
                '37': 'searchcourt.py',
                '38': 'unbanaccount.py',
                '39': 'createlink.py',
                '40': 'searchname.py',
                '41': 'searchgfw.py',
                '42': 'snostiktok.py',
                '43': 'searchgeo.py',
                '44': 'anonsend.py',
                '45': 'searchsocial.py',
                '46': 'searchgravatar.py',
                '47': 'searchroblox.py',
                '48': 'searchdoxbin.py',
                '49': 'searchemail.py',
                '50': 'searchpen.py'
            }

            if choice in scripts:  #Декоднул @allahdec.
                os.system(f'python {scripts[choice]}')
            else:  #Декоднул @allahdec.
                print('Неверный выбор опции')
        except Exception as e:  #Декоднул @allahdec.
            print(f'Произошла ошибка: {e}. Попробуйте снова.')

if __name__ == '__main__':  #Декоднул @allahdec.
    main()
